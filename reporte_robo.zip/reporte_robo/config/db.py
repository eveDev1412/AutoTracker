import MySQLdb

db_config = {
    'host': 'localhost',
    'user': 'root',
    'passwd': '',
    'db': 'autotraker',
}

def get_connection():
    return MySQLdb.connect(**db_config)