from pydantic import BaseModel

class Reporte_robo(BaseModel):
    id: int = None
    id_persona: int = None
    id_usuario: int = None
    num_serie_auto: str
    matricula: str
    id_auto: int = None
    fecha_robo: str
    hora_robo: str 
    latitud: str = None
    longitud: str = None
    tipo_robo: str
    status_reporte: str
    fecha_registro: str = None
    