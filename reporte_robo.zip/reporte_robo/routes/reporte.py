from fastapi import APIRouter, HTTPException
from config.db import get_connection
from models.Reporte import Reporte_robo

router = APIRouter()

@router.post("/reporte_robo/", response_model=Reporte_robo)
def create_reporte(reporte: Reporte_robo):
    try:
        conn = get_connection()
        cursor = conn.cursor()
        query = "INSERT INTO reporte_robo (id_persona, id_usuario, num_serie_auto, matricula, id_auto, fecha_robo, hora_robo, latitud, longitud, tipo_robo, status_reporte, fecha_registro) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
        cursor.execute(query, (
            reporte.id_persona, reporte.id_usuario, reporte.num_serie_auto, reporte.matricula, 
            reporte.id_auto, reporte.fecha_robo, reporte.hora_robo, reporte.latitud, reporte.longitud, 
            reporte.tipo_robo, reporte.status_reporte, reporte.fecha_registro
        ))
        conn.commit()
        reporte.id = cursor.lastrowid
        cursor.close()
        conn.close()
        return reporte
    except Exception as e:
        print("Error al insertar reporte:", e)
        raise HTTPException(status_code=500, detail="Error interno del servidor")

@router.get("/reporte_robo/{reporte_id}", response_model=Reporte_robo)
def get_reporte(reporte_id: int):
    try:
        conn = get_connection()
        cursor = conn.cursor()
        query = "SELECT id, id_persona, id_usuario, num_serie_auto, matricula, id_auto, fecha_robo, hora_robo, latitud, longitud, tipo_robo, status_reporte, fecha_registro FROM reporte_robo WHERE id=%s"
        cursor.execute(query, (reporte_id,))
        reporte = cursor.fetchone()
        cursor.close()
        conn.close()
        if reporte is None:
            raise HTTPException(status_code=404, detail="Reporte not found")
        return dict(zip(Reporte_robo.__fields__.keys(), reporte))
    except Exception as e:
        print("Error al obtener reporte:", e)
        raise HTTPException(status_code=500, detail="Error interno del servidor")

@router.put("/reporte_robo/{reporte_id}", response_model=Reporte_robo)
def update_reporte(reporte_id: int, reporte: Reporte_robo):
    try:
        conn = get_connection()
        cursor = conn.cursor()
        query = "UPDATE reporte_robo SET id_persona=%s, id_usuario=%s, num_serie_auto=%s, matricula=%s, id_auto=%s, fecha_robo=%s, hora_robo=%s, latitud=%s, longitud=%s, tipo_robo=%s, status_reporte=%s, fecha_registro=%s WHERE id=%s"
        cursor.execute(query, (
            reporte.id_persona, reporte.id_usuario, reporte.num_serie_auto, reporte.matricula, 
            reporte.id_auto, reporte.fecha_robo, reporte.hora_robo, reporte.latitud, reporte.longitud, 
            reporte.tipo_robo, reporte.status_reporte, reporte.fecha_registro, reporte_id
        ))
        conn.commit()
        cursor.close()
        conn.close()
        reporte.id = reporte_id
        return reporte
    except Exception as e:
        print("Error al actualizar reporte:", e)
        raise HTTPException(status_code=500, detail="Error interno del servidor")

@router.delete("/reporte_robo/{reporte_id}", response_model=Reporte_robo)
def delete_reporte(reporte_id: int):
    try:
        conn = get_connection()
        cursor = conn.cursor()
        query = "DELETE FROM reporte_robo WHERE id=%s"
        cursor.execute(query, (reporte_id,))
        conn.commit()
        cursor.close()
        conn.close()
        return {"id": reporte_id}
    except Exception as e:
        print("Error al eliminar reporte:", e)
        raise HTTPException(status_code=500, detail="Error interno del servidor")